// Frontend runs from the same server as the API, so relative paths work.
// If you deploy the frontend separately from the backend, set this to your
// backend's full URL, e.g. 'https://your-backend.onrender.com'.
const API_BASE = '';

document.getElementById('year').textContent = new Date().getFullYear();

// ---- Mobile nav toggle ----
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
navToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('is-open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});
navLinks.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// ---- Load projects from the API ----
async function loadProjects() {
  const grid = document.getElementById('projectsGrid');
  try {
    const res = await fetch(`${API_BASE}/api/projects`);
    if (!res.ok) throw new Error(`Server responded with ${res.status}`);
    const projects = await res.json();

    if (!projects.length) {
      grid.innerHTML = '<p class="state-msg">No projects yet. Add one from the backend to see it appear here.</p>';
      return;
    }

    grid.innerHTML = projects.map(renderProjectCard).join('');
  } catch (err) {
    grid.innerHTML = `<p class="state-msg is-error">Couldn't load projects right now (${escapeHtml(err.message)}). Check that the backend is running and MONGO_URI is set.</p>`;
  }
}

function renderProjectCard(project) {
  const statusClass = project.status === 'In Progress' ? 'in-progress' : 'shipped';
  const tech = (project.techStack || [])
    .map((t) => `<li>${escapeHtml(t)}</li>`)
    .join('');
  const links = [
    project.githubUrl ? `<a href="${escapeAttr(project.githubUrl)}" target="_blank" rel="noopener">Code</a>` : '',
    project.liveUrl ? `<a href="${escapeAttr(project.liveUrl)}" target="_blank" rel="noopener">Live</a>` : ''
  ].filter(Boolean).join('');

  return `
    <article class="project-card ${project.featured ? 'is-featured' : ''}">
      <div class="project-head">
        <h3>${escapeHtml(project.title)}</h3>
        <span class="status-pill ${statusClass}">${escapeHtml(project.status || 'Shipped')}</span>
      </div>
      <div class="project-category">${escapeHtml(project.category || 'General')}</div>
      <p class="project-desc">${escapeHtml(project.description)}</p>
      ${tech ? `<ul class="project-tech">${tech}</ul>` : ''}
      ${links ? `<div class="project-links">${links}</div>` : ''}
    </article>
  `;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
function escapeAttr(str) {
  return escapeHtml(str).replace(/"/g, '&quot;');
}

loadProjects();

// ---- Contact form ----
const contactForm = document.getElementById('contactForm');
const submitBtn = document.getElementById('contactSubmit');
const formStatus = document.getElementById('formStatus');

contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('name').value.trim(),
    email: document.getElementById('email').value.trim(),
    message: document.getElementById('message').value.trim()
  };

  submitBtn.disabled = true;
  submitBtn.textContent = 'Sending…';
  formStatus.textContent = '';
  formStatus.className = 'form-status';

  try {
    const res = await fetch(`${API_BASE}/api/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');

    formStatus.textContent = data.message || 'Message sent — thank you.';
    formStatus.classList.add('is-success');
    contactForm.reset();
  } catch (err) {
    formStatus.textContent = `Couldn't send that: ${err.message}`;
    formStatus.classList.add('is-error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Send message';
  }
});
