# Personal Portfolio Website

Full-stack portfolio built for Thiranex internship **Task 1**. It matches every
requirement on the task card:

| Requirement | What's used |
|---|---|
| Frontend | HTML, CSS, JavaScript |
| Backend | Node.js + Express |
| Database | MongoDB (via Mongoose) |
| Deploy target | Works on Render, Heroku, or Railway (see below) |

The backend serves both the REST API **and** the static frontend, so the whole
thing deploys as one app.

## What's inside

```
portfolio-website/
├── backend/
│   ├── server.js          # Express app entry point
│   ├── models/            # Mongoose schemas (Project, Message)
│   ├── routes/            # /api/projects and /api/contact
│   ├── seed.js            # Populates starter project data
│   ├── .env.example       # Copy to .env and fill in
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js          # Fetches projects from the API, handles the contact form
└── README.md
```

Starter data in `seed.js` already has four real projects on it — PhishGuard,
the motorcycle price predictor, the Tamil Kingdom Games passion project, and
this site itself. Edit that file to add, remove, or rewrite entries (e.g. add
GitHub/live links) before you seed the database.

## 1. Run it locally

You need Node.js 18+ and a MongoDB connection string. The fastest way to get
one for free is MongoDB Atlas:

1. Go to mongodb.com/cloud/atlas/register and create a free account.
2. Create a free **M0** cluster (any region).
3. Under **Database Access**, add a database user with a username/password.
4. Under **Network Access**, add `0.0.0.0/0` (allow access from anywhere) —
   simplest for a student project; tighten it later if you want.
5. Click **Connect → Drivers**, copy the connection string. It looks like:
   `mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/`

Then:

```bash
cd backend
npm install
cp .env.example .env
# open .env and paste your MONGO_URI, replacing <username>/<password>
npm run seed     # loads the starter projects into your database
npm start        # starts the server
```

Open **http://localhost:5000** — you should see the site, with the Work
section pulling projects live from your database. Submitting the contact
form saves a message to the `messages` collection.

## 2. Deploy it

The task lists Heroku, Netlify, or Vercel. Heroku no longer has a free tier,
and Netlify/Vercel are built for static sites or serverless functions rather
than a long-running Express server, so the most direct free option today is
**Render**, which deploys this app exactly the way Heroku used to:

1. Push this project to a GitHub repo.
2. Go to render.com → **New → Web Service** → connect your repo.
3. Set:
   - **Root directory:** `backend`
   - **Build command:** `npm install`
   - **Start command:** `npm start`
4. Under **Environment**, add `MONGO_URI` with your Atlas connection string.
5. Deploy. Render gives you a live URL — that's your submission link.
6. Run the seed script once against production data either by temporarily
   setting `MONGO_URI` in your local `.env` to the same Atlas string and
   running `npm run seed` locally, or by adding a one-off Render job.

If your task grader specifically wants to see the word "Heroku": Heroku's
paid Eco/Basic dynos deploy this project the same way (`git push heroku
main` after `heroku create` and `heroku config:set MONGO_URI=...`) — the code
doesn't need to change either way.

## 3. Before you submit

- [ ] Edit `backend/seed.js` with your own project details, links, and any
      screenshots/live demo URLs you want to add.
- [ ] Update the About and Experience sections in `frontend/index.html` if
      anything about your internships or coursework has changed.
- [ ] Re-run `npm run seed` after editing project data, then redeploy.
- [ ] Test the deployed link in an incognito window before submitting —
      make sure `MONGO_URI` is set in Render's environment, not just locally.
- [ ] Paste the live Render URL (and your GitHub repo link) into the
      "Submit Work" field on the Thiranex task page.

## Notes

- Contact form submissions are stored in MongoDB but not emailed anywhere.
  If you want an email notification instead, the `POST /api/contact` route
  in `backend/routes/contact.js` is the place to add that (e.g. with
  Nodemailer or an email API).
- CORS is left open (`cors()` with no options) since frontend and backend
  ship together. Restrict it if you ever split them across two domains.
