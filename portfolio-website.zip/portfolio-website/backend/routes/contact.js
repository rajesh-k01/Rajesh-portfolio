const express = require('express');
const router = express.Router();
const Message = require('../models/Message');

// POST /api/contact — store a message sent from the contact form
router.post('/', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Name, email and message are all required.' });
    }
    const saved = await Message.create({ name, email, message });
    res.status(201).json({ id: saved._id, message: 'Thanks — your message has been received.' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
