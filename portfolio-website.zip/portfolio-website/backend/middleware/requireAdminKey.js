// Simple shared-secret check for endpoints that change data (add/edit/delete
// a project). The person calling the API must send the same key that's set
// in the server's ADMIN_KEY environment variable, as a header:
//
//   x-admin-key: <your key>
//
// This is intentionally lightweight (no user accounts, no sessions) — enough
// to stop a random visitor from deleting your projects, without the overhead
// of a full auth system for a personal portfolio site.
module.exports = function requireAdminKey(req, res, next) {
  const provided = req.header('x-admin-key');
  const expected = process.env.ADMIN_KEY;

  if (!expected) {
    // Fails closed: if the server owner hasn't set a key, writes are blocked
    // rather than silently left open.
    return res.status(500).json({ error: 'Server is missing ADMIN_KEY configuration.' });
  }
  if (!provided || provided !== expected) {
    return res.status(401).json({ error: 'Missing or invalid x-admin-key header.' });
  }
  next();
};
