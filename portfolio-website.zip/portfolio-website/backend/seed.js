// Populates the database with starter project data so the site isn't empty
// on first run. Edit this list freely — add, remove, or rewrite entries to
// match your own projects, then run `npm run seed` again.
require('dotenv').config();
const mongoose = require('mongoose');
const Project = require('./models/Project');

const projects = [
  {
    title: 'PhishGuard — Phishing Detection',
    description:
      'A full-stack Flask app that scores suspicious URLs using five machine learning models trained on the LegitPhish dataset, comparing their predictions side by side.',
    techStack: ['Python', 'Flask', 'XGBoost', 'Random Forest', 'SVM', 'scikit-learn'],
    category: 'Machine Learning',
    status: 'Shipped',
    featured: true
  },
  {
    title: 'Used Motorcycle Price Predictor',
    description:
      'A regression model that estimates resale prices for used motorcycles from real listing data, covering data cleaning, feature engineering, and model evaluation.',
    techStack: ['Python', 'Pandas', 'scikit-learn', 'Regression'],
    category: 'Machine Learning',
    status: 'Shipped',
    featured: true
  },
  {
    title: 'Tamil Kingdom Games',
    description:
      'A browser-based battle game set in the Chola era, with historically inspired factions and weapons — an ongoing passion project exploring Tamil kingdom history through interactive design.',
    techStack: ['JavaScript', 'HTML5 Canvas'],
    category: 'Game Development',
    status: 'In Progress',
    featured: true
  },
  {
    title: 'This Portfolio',
    description:
      'The full-stack site you\'re looking at right now — a Node/Express API backed by MongoDB, serving project data to a static frontend.',
    techStack: ['Node.js', 'Express', 'MongoDB', 'JavaScript'],
    category: 'Full-Stack Web',
    status: 'Shipped',
    featured: false
  }
];

mongoose
  .connect(process.env.MONGO_URI)
  .then(async () => {
    await Project.deleteMany({});
    await Project.insertMany(projects);
    console.log(`Seeded ${projects.length} projects.`);
    process.exit(0);
  })
  .catch((err) => {
    console.error('Seed failed:', err.message);
    process.exit(1);
  });
